import './globals.css';

export const metadata = {
  title: 'Echi - El Guardian de las Defensas',
  description: 'Ayuda a Echi a proteger tu cuerpo activando el escudo contra los virus.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>
        <div id="game-root">
          {children}
        </div>
      </body>
    </html>
  );
}
