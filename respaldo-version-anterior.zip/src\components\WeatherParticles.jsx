'use client';

import { useEffect, useRef, useMemo } from 'react';

const WEATHER_PARTICLES = {
  rain: { count: 40, type: 'rain' },
  snow: { count: 30, type: 'snow' },
  cloudy: { count: 0, type: null },
};

export default function WeatherParticles({ weather }) {
  const particles = useMemo(() => {
    const cfg = WEATHER_PARTICLES[weather] || { count: 0 };
    if (!cfg.count) return [];
    return Array.from({ length: cfg.count }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 3,
      duration: cfg.type === 'rain' ? 0.5 + Math.random() * 0.5 : 4 + Math.random() * 4,
      size: cfg.type === 'rain' ? 18 + Math.random() * 20 : 3 + Math.random() * 5,
    }));
  }, [weather]);

  if (!particles.length) return null;

  return (
    <div className="weather-particles">
      {particles.map(p => (
        weather === 'rain' ? (
          <div
            key={p.id}
            className="rain-drop"
            style={{
              left: `${p.left}%`,
              height: `${p.size}px`,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              top: '-20px',
            }}
          />
        ) : (
          <div
            key={p.id}
            className="snow-flake"
            style={{
              left: `${p.left}%`,
              width: `${p.size}px`,
              height: `${p.size}px`,
              animationDelay: `${p.delay}s`,
              animationDuration: `${p.duration}s`,
              top: '-10px',
            }}
          />
        )
      ))}
    </div>
  );
}
