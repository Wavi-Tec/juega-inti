'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import dynamic from 'next/dynamic';
import WeatherParticles from './WeatherParticles';
import { soundManager } from '@/utils/audio';

// Dynamic import of Three.js canvas to ensure client-only rendering
const GameScene = dynamic(() => import('./GameScene'), { ssr: false });

// ── Configuración General del Juego ─────────────────────────────────────────
const TOTAL_TIME = 75; // 75 segundos de experiencia ideal para promociones (25s por clima)

const WEATHER_STAGES = [
  { atSecondsLeft: 75, weather: 'cloudy' },
  { atSecondsLeft: 50, weather: 'rain' },
  { atSecondsLeft: 25, weather: 'snow' },
];

const MAX_OPPORTUNITIES = 5;
const SHIELD_DURATION = 750; // ms de apertura del escudo

// Mensajes Educativos oficiales para los 3 momentos de cambio de clima
const CLIMATE_MESSAGES = {
  cloudy: {
    stage: 'Etapa 1: Defensas',
    icon: '☁️',
    title: 'Defensas Naturales',
    subtitle: 'El escudo que te acompaña',
    body: 'Nuestro organismo cuenta con un sistema natural de protección. Echi simboliza el cuidado diario que ayuda a mantener las defensas activas frente a los agentes del entorno.',
    tip: 'Toca a Echi cuando los virus se acerquen para abrir el escudo protector.',
    buttonText: '¡Aprender y Jugar!',
  },
  rain: {
    stage: 'Etapa 2: Cambios Estacionales',
    icon: '🌧️',
    title: 'Cambios Estacionales',
    subtitle: 'Mayor exigencia para el organismo',
    body: 'Las variaciones de temperatura y humedad en días lluviosos ponen a prueba nuestra respuesta. Los hábitos saludables constantes son clave para no bajar la guardia.',
    tip: 'Los virus avanzan más rápido: anticipa el toque con precisión.',
    buttonText: '¡Continuar!',
  },
  snow: {
    stage: 'Etapa 3: Vías Respiratorias',
    icon: '❄️',
    title: 'Resfrío y Vías Respiratorias',
    subtitle: 'El reto final de la temporada',
    body: 'El frío intenso y los ambientes cerrados desafían nuestras vías respiratorias. Mantener una nutrición equilibrada y protección adecuada hace la diferencia.',
    tip: '¡Llegan en grupo! Mantén la racha para hacer florecer el escudo.',
    buttonText: '¡Reto Final!',
  },
};

const WEATHER_INFO = {
  cloudy: { name: 'Nublado', icon: '☁️', color: '#81ecec', badge: '☁️ Clima Nublado' },
  rain:   { name: 'Lluvia',  icon: '🌧️', color: '#74b9ff', badge: '🌧️ Lluvia Estacional' },
  snow:   { name: 'Nieve',   icon: '❄️', color: '#a29bfe', badge: '❄️ Nieve Extrema' },
};

export default function EchiGame() {
  // Estados del juego
  const [status, setStatus]             = useState('idle'); // 'idle' | 'climate_msg' | 'playing' | 'gameover'
  const [score, setScore]               = useState(0);
  const [streak, setStreak]             = useState(0);
  const [maxStreak, setMaxStreak]       = useState(0);
  const [blockedCount, setBlockedCount] = useState(0);
  const [opportunities, setOpportunities] = useState(MAX_OPPORTUNITIES);
  const [missCount, setMissCount]       = useState(0);
  const [timeLeft, setTimeLeft]         = useState(TOTAL_TIME);
  const [weather, setWeather]           = useState('cloudy');
  const [shieldActive, setShield]       = useState(false);
  const [pendingWeather, setPending]   = useState(null);
  const [climateMsg, setClimateMsg]     = useState(null);
  const [floatTexts, setFloatTexts]     = useState([]);
  const [isMuted, setIsMuted]           = useState(false);
  const [bannerAutoCountdown, setBannerAutoCountdown] = useState(5);

  // Referencias mutables para intervalos y llamadas asíncronas
  const timerRef = useRef(null);
  const autoResumeTimerRef = useRef(null);
  const shieldTimeoutRef = useRef(null);
  const floatIdRef = useRef(0);
  const streakRef = useRef(0);
  const opportunitiesRef = useRef(MAX_OPPORTUNITIES);

  useEffect(() => { streakRef.current = streak; }, [streak]);
  useEffect(() => { opportunitiesRef.current = opportunities; }, [opportunities]);

  // Actualizar clase en body para transición visual atmosférica
  useEffect(() => {
    document.body.className = `weather-${weather}`;
  }, [weather]);

  // Soporte para tecla Espacio
  useEffect(() => {
    const onKeyDown = (e) => {
      if (e.code === 'Space' && status === 'playing') {
        e.preventDefault();
        activateShield();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [status]);

  // ── Temporizador Principal (Corre toda la partida sin cancelarse) ───────────
  useEffect(() => {
    if (status !== 'playing') {
      clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        const next = prev - 1;

        // Comprobar transiciones de clima
        if (next === 50 && weather !== 'rain') {
          triggerWeatherTransition('rain');
        } else if (next === 25 && weather !== 'snow') {
          triggerWeatherTransition('snow');
        }

        if (next <= 0) {
          clearInterval(timerRef.current);
          finishGame();
          return 0;
        }
        return next;
      });
    }, 1000);

    return () => clearInterval(timerRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, weather]);

  // ── Transición Educativa de Clima ──────────────────────────────────────────
  const triggerWeatherTransition = (newWeather) => {
    clearInterval(timerRef.current);
    soundManager.playWeatherChange();
    setPending(newWeather);
    setClimateMsg(CLIMATE_MESSAGES[newWeather]);
    setBannerAutoCountdown(5);
    setStatus('climate_msg');

    // Auto-reanudar después de 5 segundos para que la experiencia fluya sola en stands
    clearInterval(autoResumeTimerRef.current);
    let count = 5;
    autoResumeTimerRef.current = setInterval(() => {
      count -= 1;
      setBannerAutoCountdown(count);
      if (count <= 0) {
        clearInterval(autoResumeTimerRef.current);
        resumeFromClimate(newWeather);
      }
    }, 1000);
  };

  const resumeFromClimate = (nextW) => {
    clearInterval(autoResumeTimerRef.current);
    const targetWeather = nextW || pendingWeather || 'cloudy';
    setWeather(targetWeather);
    setClimateMsg(null);
    setStatus('playing');
  };

  // ── Inicio de Partida ──────────────────────────────────────────────────────
  const startGame = () => {
    setScore(0);
    setStreak(0);
    setMaxStreak(0);
    setBlockedCount(0);
    setOpportunities(MAX_OPPORTUNITIES);
    setMissCount(0);
    setTimeLeft(TOTAL_TIME);
    setWeather('cloudy');
    setShield(false);
    setFloatTexts([]);

    // Comenzar con la primera explicación breve
    setPending('cloudy');
    setClimateMsg(CLIMATE_MESSAGES.cloudy);
    setBannerAutoCountdown(6);
    setStatus('climate_msg');

    clearInterval(autoResumeTimerRef.current);
    let count = 6;
    autoResumeTimerRef.current = setInterval(() => {
      count -= 1;
      setBannerAutoCountdown(count);
      if (count <= 0) {
        clearInterval(autoResumeTimerRef.current);
        resumeFromClimate('cloudy');
      }
    }, 1000);
  };

  const finishGame = () => {
    setStatus('gameover');
    setShield(false);
    clearInterval(timerRef.current);
    clearInterval(autoResumeTimerRef.current);
    soundManager.playVictory();
  };

  // ── Activación de Escudo ───────────────────────────────────────────────────
  const activateShield = useCallback(() => {
    if (status !== 'playing') return;

    soundManager.playShield();
    clearTimeout(shieldTimeoutRef.current);
    setShield(true);

    shieldTimeoutRef.current = setTimeout(() => {
      setShield(false);
    }, SHIELD_DURATION);
  }, [status]);

  // ── Bloqueo Exitoso (Suma puntos y florece el escudo con racha) ───────────
  const handleScore = useCallback((virusId) => {
    setBlockedCount((prev) => prev + 1);

    const nextStreak = streakRef.current + 1;
    setStreak(nextStreak);
    setMaxStreak((prev) => Math.max(prev, nextStreak));

    // Multiplicador por racha y florecimiento
    let multiplier = 1;
    let bloomText = '';

    if (nextStreak >= 6) {
      multiplier = 3;
      bloomText = '🌺 ¡SÚPER FLORECIMIENTO!';
      soundManager.playBloom();
    } else if (nextStreak >= 3) {
      multiplier = 2;
      bloomText = '🌸 ¡ESCUDO FLORECIENDO!';
      if (nextStreak === 3) soundManager.playBloom();
    }

    soundManager.playBlock(nextStreak);

    const pts = 15 * multiplier;
    setScore((prev) => prev + pts);

    // Texto flotante de impacto
    addFloat(
      nextStreak >= 3 ? `${bloomText} +${pts}` : `+${pts}`,
      nextStreak >= 3 ? '#ff9ff3' : '#ffd700'
    );

    // Si perdió oportunidades y logra racha de 4, recupera 1 oportunidad
    if (nextStreak % 4 === 0 && opportunitiesRef.current < MAX_OPPORTUNITIES) {
      setOpportunities((prev) => {
        const recovered = Math.min(MAX_OPPORTUNITIES, prev + 1);
        addFloat('💚 ¡Defensa Recuperada!', '#1dd1a1');
        return recovered;
      });
    }
  }, []);

  // ── Si el virus pasa: Pierdes una oportunidad, PERO SIGUES JUGANDO ────────
  const handleMiss = useCallback((virusId) => {
    setStreak(0);
    setMissCount((prev) => prev + 1);
    soundManager.playMiss();

    setOpportunities((prev) => {
      const next = prev - 1;
      if (next <= 0) {
        // Modo Alerta Inmune: no corta el juego, pero alerta visualmente
        addFloat('⚠️ ¡Defensas al límite! Mantén el toque', '#ff4757');
        return 0;
      } else {
        addFloat('💔 -1 Oportunidad', '#ff6b6b');
        return next;
      }
    });
  }, []);

  // Utilidad para textos flotantes llamativos
  const addFloat = (text, color) => {
    const id = floatIdRef.current++;
    const x = 38 + (Math.random() - 0.5) * 20;
    const y = 30 + (Math.random() - 0.5) * 15;
    setFloatTexts((prev) => [...prev, { id, text, color, x, y }]);
    setTimeout(() => {
      setFloatTexts((prev) => prev.filter((f) => f.id !== id));
    }, 1100);
  };

  // Toggle sonido
  const toggleMute = () => {
    const isNowMuted = soundManager.toggleSound();
    setIsMuted(!isNowMuted);
  };

  // Porcentaje del tiempo para la barra superior
  const timerPct = Math.max(0, (timeLeft / TOTAL_TIME) * 100);
  const isSnowWeather = weather === 'snow';
  const isBlooming = streak >= 3;

  return (
    <div id="game-container" style={{ position: 'relative', width: '100vw', height: '100vh', overflow: 'hidden' }}>
      {/* Canvas 3D de Three.js */}
      {status !== 'idle' && (
        <GameScene
          gameState={{ status, weather }}
          streak={streak}
          shieldActive={shieldActive}
          onScore={handleScore}
          onMiss={handleMiss}
          onEchiClick={activateShield}
        />
      )}

      {/* Partículas del clima (Lluvia o Nieve) */}
      <WeatherParticles weather={weather} />

      {/* ── Barra Superior HUD ──────────────────────────────────────────────── */}
      {(status === 'playing' || status === 'climate_msg') && (
        <>
          <header className="hud-top">
            {/* Puntuación y Racha */}
            <div className={`hud-pill ${isSnowWeather ? 'snow-mode' : ''}`}>
              <span>⭐</span>
              <span className="score-num">{score}</span>
              {streak >= 3 && (
                <span className={`streak-badge ${streak >= 6 ? 'super-bloom' : ''}`}>
                  {streak >= 6 ? '🌺 x' : '🌸 x'}{streak}
                </span>
              )}
            </div>

            {/* Oportunidades restantes */}
            <div className={`hud-pill ${isSnowWeather ? 'snow-mode' : ''}`}>
              <span style={{ fontSize: '0.85rem', marginRight: '4px', opacity: 0.85 }}>Defensas:</span>
              <div className="hud-lives">
                {Array.from({ length: MAX_OPPORTUNITIES }, (_, i) => (
                  <span
                    key={i}
                    className={`life-icon ${i >= opportunities ? 'lost' : ''}`}
                    title={i >= opportunities ? 'Oportunidad perdida' : 'Defensa activa'}
                  >
                    🛡️
                  </span>
                ))}
              </div>
            </div>

            {/* Botón de Sonido */}
            <button
              onClick={toggleMute}
              className={`hud-pill sound-btn ${isSnowWeather ? 'snow-mode' : ''}`}
              title={isMuted ? 'Activar sonido' : 'Silenciar'}
              style={{ pointerEvents: 'all', cursor: 'pointer' }}
            >
              {isMuted ? '🔇' : '🔊'}
            </button>
          </header>

          {/* Barra de Tiempo Transcurrido */}
          <div className="timer-bar-wrap">
            <div className="timer-bar-bg">
              <div
                className="timer-bar-fill"
                style={{
                  width: `${timerPct}%`,
                  background:
                    timerPct > 45
                      ? 'linear-gradient(90deg, #4fc3f7, #00d2d3)'
                      : timerPct > 20
                      ? 'linear-gradient(90deg, #feca57, #ff9f43)'
                      : 'linear-gradient(90deg, #ff6b6b, #ee5253)',
                }}
              />
            </div>
            <div className="timer-info">
              <span>⏱️ {timeLeft}s restantes</span>
              <span>{WEATHER_INFO[weather]?.badge}</span>
            </div>
          </div>

          {/* Indicador de Florecimiento de Escudo si racha activa */}
          {isBlooming && (
            <div className="bloom-indicator">
              🌸 ¡Escudo de Equinácea Florecido! (Multiplicador Activo)
            </div>
          )}
        </>
      )}

      {/* ── Botón de Toque Gigante para Móvil / Tablet / Stand ─────────────── */}
      {status === 'playing' && (
        <div className="touch-action-container">
          <button
            id="btn-touch-echi"
            className={`action-touch-btn ${shieldActive ? 'active' : ''}`}
            onClick={activateShield}
          >
            <span className="btn-icon">🛡️</span>
            <span className="btn-label">
              {shieldActive ? '¡ESCUDO ACTIVO!' : 'TOCA A ECHI'}
            </span>
          </button>
          <div className="touch-subhint">o toca a Echi directamente en la pantalla</div>
        </div>
      )}

      {/* ── Textos Flotantes de Puntos y Mensajes ─────────────────────────── */}
      {floatTexts.map((f) => (
        <div
          key={f.id}
          className="float-text"
          style={{ left: `${f.x}%`, top: `${f.y}%`, color: f.color }}
        >
          {f.text}
        </div>
      ))}

      {/* ── Modal Educativo en Cambio de Clima (Momento del Promotor) ──────── */}
      {status === 'climate_msg' && climateMsg && (
        <div className="screen-overlay" style={{ background: 'rgba(10, 18, 38, 0.88)' }}>
          <div className="climate-card">
            <div className="climate-header">
              <span className="climate-stage-pill">{climateMsg.stage}</span>
              <div className="climate-icon-big">{climateMsg.icon}</div>
              <h2 className="climate-card-title">{climateMsg.title}</h2>
              <p className="climate-card-sub">{climateMsg.subtitle}</p>
            </div>

            <div className="climate-card-body">
              <p>{climateMsg.body}</p>
              <div className="climate-tip-box">
                <span className="tip-badge">💡 Consejo de Juego:</span> {climateMsg.tip}
              </div>
            </div>

            <div className="climate-actions">
              <button
                id="btn-resume-game"
                className="btn-primary"
                onClick={() => resumeFromClimate()}
              >
                {climateMsg.buttonText} ({bannerAutoCountdown}s)
              </button>
            </div>

            <div className="symbolic-disclaimer">
              *Los personajes y el escudo son simbólicos. Una alimentación saludable y hábitos de vida fortalecen el bienestar.
            </div>
          </div>
        </div>
      )}

      {/* ── Pantalla de Inicio (Presentación) ──────────────────────────────── */}
      {status === 'idle' && (
        <div className="screen-overlay">
          <div className="welcome-container">
            <div className="game-brand-pill">INTI • Salud y Bienestar</div>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/echi.jpg" alt="Echi Guardián" className="echi-preview" />
            <h1 className="screen-title">ECHI</h1>
            <p className="screen-subtitle-lead">El Guardián de tus Defensas</p>

            <p className="screen-sub">
              Acompaña a Echi a través de las tres estaciones. Activa el escudo en el momento justo
              para proteger a la persona de los virus y haz florecer las defensas.
            </p>

            <div className="instructions-grid">
              <div className="inst-card">
                <div className="icon">☁️</div>
                <div className="title">1. Nublado</div>
                <div className="label">Defensas naturales</div>
              </div>
              <div className="inst-card">
                <div className="icon">🌧️</div>
                <div className="title">2. Lluvia</div>
                <div className="label">Cambios de estación</div>
              </div>
              <div className="inst-card">
                <div className="icon">❄️</div>
                <div className="title">3. Nieve</div>
                <div className="label">Vías respiratorias</div>
              </div>
            </div>

            <button id="btn-start-game" className="btn-primary" onClick={startGame}>
              ¡Comenzar la Partida!
            </button>

            <p className="disclaimer-text">
              Juego lúdico interactivo para dinámicas informativas de salud y nutrición.
            </p>
          </div>
        </div>
      )}

      {/* ── Pantalla de Fin de Juego (Resumen Educativo y Puntuación) ───────── */}
      {status === 'gameover' && (
        <div className="screen-overlay">
          <div className="gameover-card">
            <div className="trophy-icon">
              {score >= 350 ? '🏆' : score >= 200 ? '⭐' : '🌱'}
            </div>
            <h2 className="screen-title" style={{ fontSize: '2.4rem', marginBottom: '4px' }}>
              ¡Misión Completada!
            </h2>
            <p className="screen-sub" style={{ marginBottom: '18px' }}>
              Has protegido las defensas a lo largo de todo el ciclo estacional.
            </p>

            {/* Marcador Principal */}
            <div className="score-summary-grid">
              <div className="summary-stat">
                <span className="stat-label">Puntos Totales</span>
                <span className="stat-value">{score}</span>
              </div>
              <div className="summary-stat">
                <span className="stat-label">Virus Bloqueados</span>
                <span className="stat-value">{blockedCount}</span>
              </div>
              <div className="summary-stat">
                <span className="stat-label">Mayor Racha</span>
                <span className="stat-value">{maxStreak >= 3 ? `🌸 x${maxStreak}` : `${maxStreak}`}</span>
              </div>
              <div className="summary-stat">
                <span className="stat-label">Defensas Finales</span>
                <span className="stat-value">{opportunities}/{MAX_OPPORTUNITIES}</span>
              </div>
            </div>

            {/* Mensaje de Logro */}
            <div className="achievement-box">
              {maxStreak >= 6 ? (
                <p>🌺 <strong>¡Nivel Experto en Defensas!</strong> Lograste el Súper Florecimiento del escudo de Equinácea.</p>
              ) : maxStreak >= 3 ? (
                <p>🌸 <strong>¡Excelente Protección!</strong> Hiciste florecer el escudo gracias a tu precisión.</p>
              ) : (
                <p>💪 <strong>¡Buen Desempeño!</strong> Completaste todas las etapas climáticas de la experiencia.</p>
              )}
            </div>

            <div className="education-recap">
              <div className="recap-item"><span>☁️ Defensas:</span> Cuidado continuo</div>
              <div className="recap-item"><span>🌧️ Estaciones:</span> Protección oportuna</div>
              <div className="recap-item"><span>❄️ Respiratorias:</span> Bienestar integral</div>
            </div>

            <button id="btn-play-again" className="btn-primary" onClick={startGame}>
              🔄 Jugar Otra Partida
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
