'use client';

import { useRef, useEffect } from 'react';
import * as THREE from 'three';

// ── Configuraciones por Clima ──────────────────────────────────────────────
const WEATHER_CONFIG = {
  cloudy: {
    spawnInterval: 2800,
    baseSpeed: 0.018,
    speedVariation: 0.006,
    maxViruses: 3,
    type: 'cloudy',
    color: 0x9b59b6,
    spikeColor: 0xff6b6b,
  },
  rain: {
    spawnInterval: 1800,
    baseSpeed: 0.032,
    speedVariation: 0.012,
    maxViruses: 6,
    type: 'rain',
    color: 0x2980b9,
    spikeColor: 0x00d2d3,
  },
  snow: {
    spawnInterval: 1100,
    baseSpeed: 0.046,
    speedVariation: 0.018,
    maxViruses: 8,
    type: 'snow',
    color: 0x546de5,
    spikeColor: 0xffffff,
  },
};

// Spawn bounds (los virus nacen a la izquierda y van hacia la derecha donde está Echi)
function randomSpawn() {
  return {
    x: -9 - Math.random() * 2,
    y: (Math.random() - 0.5) * 4.2,
    z: 0,
    sineFreq: 2 + Math.random() * 3,
    sineAmp: 0.15 + Math.random() * 0.25,
    seed: Math.random() * Math.PI * 2,
  };
}

let virusGlobalId = 0;

export default function GameScene({
  gameState,
  streak,
  shieldActive,
  onScore,
  onMiss,
  onEchiClick,
}) {
  const mountRef = useRef(null);
  const sceneRef = useRef(null);
  const virusesRef = useRef([]);
  const echiRef = useRef(null);
  const echiVisualsRef = useRef({});
  const petalsGroupRef = useRef(null);
  const shieldMeshRef = useRef(null);
  const outerGlowRef = useRef(null);
  const personRef = useRef(null);
  const particlesRef = useRef([]);
  const frameRef = useRef(null);
  const spawnTimerRef = useRef(null);

  // References to keep in sync without recreation
  const shieldActiveRef = useRef(shieldActive);
  const streakRef = useRef(streak);
  const gameStateRef = useRef(gameState);
  const lastTimeRef = useRef(performance.now());
  const tapSquashRef = useRef(1);

  useEffect(() => {
    shieldActiveRef.current = shieldActive;
    if (shieldActive) {
      tapSquashRef.current = 1.35; // Squash & stretch burst on tap!
    }
  }, [shieldActive]);

  useEffect(() => {
    streakRef.current = streak;
  }, [streak]);

  useEffect(() => {
    gameStateRef.current = gameState;
  }, [gameState]);

  // ── Inicialización de la Escena Three.js ──────────────────────────────────
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    mount.appendChild(renderer.domElement);

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Camera (Orthographic para un juego 2.5D nítido y accesible)
    const aspect = mount.clientWidth / mount.clientHeight;
    const frustumSize = 11;
    const camera = new THREE.OrthographicCamera(
      (-frustumSize * aspect) / 2,
      (frustumSize * aspect) / 2,
      frustumSize / 2,
      -frustumSize / 2,
      0.1,
      100
    );
    camera.position.set(0, 0, 20);

    // Luces
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.9);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xfff7e6, 0.9);
    dirLight1.position.set(6, 8, 10);
    scene.add(dirLight1);

    const pointLight = new THREE.PointLight(0x4fc3f7, 1.2, 15);
    pointLight.position.set(3.5, 0, 3);
    scene.add(pointLight);

    // ────────────────────────────────────────────────────────────────────────
    // 1. PERSONAJE ECHI (Guardián Inmunitario) en X = +3.4
    // ────────────────────────────────────────────────────────────────────────
    const echiGroup = new THREE.Group();
    echiGroup.position.set(3.4, 0, 0);

    // Cuerpo esférico perlado suave
    const echiBodyGeo = new THREE.SphereGeometry(0.95, 36, 36);
    const echiBodyMat = new THREE.MeshStandardMaterial({
      color: 0xf5fbff,
      emissive: 0x81d4fa,
      emissiveIntensity: 0.35,
      roughness: 0.25,
      metalness: 0.1,
    });
    const echiBody = new THREE.Mesh(echiBodyGeo, echiBodyMat);
    echiGroup.add(echiBody);

    // Ojos tiernos
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0x1a252f });
    const eyeHighlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 16), eyeMat);
    eyeL.position.set(-0.32, 0.2, 0.88);
    const eyeLSparkle = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 12), eyeHighlightMat);
    eyeLSparkle.position.set(-0.29, 0.24, 0.98);
    echiGroup.add(eyeL, eyeLSparkle);

    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 16), eyeMat);
    eyeR.position.set(0.32, 0.2, 0.88);
    const eyeRSparkle = new THREE.Mesh(new THREE.SphereGeometry(0.04, 12, 12), eyeHighlightMat);
    eyeRSparkle.position.set(0.35, 0.24, 0.98);
    echiGroup.add(eyeR, eyeRSparkle);

    // Mejillas sonrosadas (blush)
    const blushMat = new THREE.MeshBasicMaterial({
      color: 0xff8fa3,
      transparent: true,
      opacity: 0.75,
    });
    const blushL = new THREE.Mesh(new THREE.CircleGeometry(0.14, 16), blushMat);
    blushL.position.set(-0.46, 0.03, 0.86);
    blushL.rotation.y = -0.3;
    const blushR = new THREE.Mesh(new THREE.CircleGeometry(0.14, 16), blushMat);
    blushR.position.set(0.46, 0.03, 0.86);
    blushR.rotation.y = 0.3;
    echiGroup.add(blushL, blushR);

    // Sonrisa
    const smileCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.2, -0.1, 0.9),
      new THREE.Vector3(0, -0.22, 0.92),
      new THREE.Vector3(0.2, -0.1, 0.9),
    ]);
    const smileGeo = new THREE.TubeGeometry(smileCurve, 16, 0.025, 8, false);
    const smileMesh = new THREE.Mesh(smileGeo, eyeMat);
    echiGroup.add(smileMesh);

    // Manitas saludando
    const handGeo = new THREE.SphereGeometry(0.22, 16, 16);
    const handMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.3,
    });
    const handL = new THREE.Mesh(handGeo, handMat);
    handL.position.set(-0.95, -0.1, 0.2);
    const handR = new THREE.Mesh(handGeo, handMat);
    handR.position.set(0.95, 0.1, 0.2);
    echiGroup.add(handL, handR);

    // Pies pequeños
    const footL = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 16), handMat);
    footL.position.set(-0.35, -0.85, 0.2);
    footL.scale.set(1, 0.7, 1.2);
    const footR = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 16), handMat);
    footR.position.set(0.35, -0.85, 0.2);
    footR.scale.set(1, 0.7, 1.2);
    echiGroup.add(footL, footR);

    // ────────────────────────────────────────────────────────────────────────
    // ESCUDO BASE (Burbuja de energía)
    // ────────────────────────────────────────────────────────────────────────
    const shieldGeo = new THREE.SphereGeometry(1.65, 32, 32);
    const shieldMat = new THREE.MeshStandardMaterial({
      color: 0x4fc3f7,
      emissive: 0x29b6f6,
      emissiveIntensity: 0.8,
      transparent: true,
      opacity: 0,
      roughness: 0.1,
      metalness: 0.2,
      side: THREE.DoubleSide,
    });
    const shieldMesh = new THREE.Mesh(shieldGeo, shieldMat);
    shieldMesh.scale.set(1.1, 1.1, 0.7);
    echiGroup.add(shieldMesh);
    shieldMeshRef.current = shieldMesh;

    // Aro exterior pulsante de fuerza
    const glowRingGeo = new THREE.RingGeometry(1.68, 1.95, 48);
    const glowRingMat = new THREE.MeshBasicMaterial({
      color: 0xffd54f,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
    });
    const glowRing = new THREE.Mesh(glowRingGeo, glowRingMat);
    echiGroup.add(glowRing);
    outerGlowRef.current = glowRing;

    // ────────────────────────────────────────────────────────────────────────
    // FLORECIMIENTO DEL ESCUDO (Pétalos de Equinácea / Echinacea Bloom)
    // Se activan y florecen cuando la racha supera 3 aciertos seguidos!
    // ────────────────────────────────────────────────────────────────────────
    const petalsGroup = new THREE.Group();
    const petalCount = 10;
    const petalShape = new THREE.Shape();
    petalShape.moveTo(0, 0);
    petalShape.quadraticCurveTo(0.3, 0.7, 0.18, 1.3);
    petalShape.quadraticCurveTo(0, 1.6, -0.18, 1.3);
    petalShape.quadraticCurveTo(-0.3, 0.7, 0, 0);

    const petalGeo = new THREE.ShapeGeometry(petalShape);
    const petalMat = new THREE.MeshStandardMaterial({
      color: 0xff6b8b,
      emissive: 0xff3366,
      emissiveIntensity: 0.4,
      roughness: 0.3,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
    });

    for (let i = 0; i < petalCount; i++) {
      const petalMesh = new THREE.Mesh(petalGeo, petalMat);
      const angle = (i / petalCount) * Math.PI * 2;
      petalMesh.position.set(0, 0, -0.05);
      petalMesh.rotation.z = angle - Math.PI / 2;
      petalMesh.scale.set(1, 1, 1);
      petalsGroup.add(petalMesh);
    }
    petalsGroup.scale.set(0.001, 0.001, 0.001); // Oculto al inicio
    echiGroup.add(petalsGroup);
    petalsGroupRef.current = petalsGroup;

    scene.add(echiGroup);
    echiRef.current = echiGroup;
    echiVisualsRef.current = { handL, handR, footL, footR, echiBody };

    // ────────────────────────────────────────────────────────────────────────
    // 2. PERSONA A PROTEGER (Silueta amigable a la izquierda X = -4.5)
    // ────────────────────────────────────────────────────────────────────────
    const personGroup = new THREE.Group();
    personGroup.position.set(-4.5, 0, 0);

    // Cabeza
    const personHead = new THREE.Mesh(
      new THREE.SphereGeometry(0.75, 24, 24),
      new THREE.MeshStandardMaterial({ color: 0xfbd0b0, roughness: 0.6 })
    );
    personHead.position.y = 1.35;
    personGroup.add(personHead);

    // Cabello / Gorrito
    const hair = new THREE.Mesh(
      new THREE.SphereGeometry(0.78, 20, 20, 0, Math.PI * 2, 0, Math.PI * 0.55),
      new THREE.MeshStandardMaterial({ color: 0x4a3728, roughness: 0.8 })
    );
    hair.position.y = 1.45;
    personGroup.add(hair);

    // Abrigo / Ropa cálida
    const coat = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.85, 2.0, 20),
      new THREE.MeshStandardMaterial({ color: 0x2e86de, roughness: 0.5 })
    );
    coat.position.y = -0.1;
    personGroup.add(coat);

    // Bufanda protectora
    const scarf = new THREE.Mesh(
      new THREE.TorusGeometry(0.6, 0.22, 16, 24),
      new THREE.MeshStandardMaterial({ color: 0xff9f43, roughness: 0.6 })
    );
    scarf.rotation.x = Math.PI / 2;
    scarf.position.y = 0.8;
    personGroup.add(scarf);

    // Aura de bienestar (corazón protector suave)
    const auraGeo = new THREE.RingGeometry(1.2, 1.35, 32);
    const auraMat = new THREE.MeshBasicMaterial({
      color: 0x1dd1a1,
      transparent: true,
      opacity: 0.35,
      side: THREE.DoubleSide,
    });
    const aura = new THREE.Mesh(auraGeo, auraMat);
    aura.position.y = 0.4;
    personGroup.add(aura);

    scene.add(personGroup);
    personRef.current = personGroup;

    // ────────────────────────────────────────────────────────────────────────
    // Raycaster para interactuar al tocar a Echi
    // ────────────────────────────────────────────────────────────────────────
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const handlePointerDown = (clientX, clientY) => {
      const rect = mount.getBoundingClientRect();
      mouse.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);

      // Si hace clic cerca o sobre el grupo de Echi
      const hits = raycaster.intersectObjects(echiGroup.children, true);
      if (hits.length > 0 || (mouse.x > 0.1 && mouse.x < 0.8)) {
        onEchiClick();
      }
    };

    const onMouseDown = (e) => handlePointerDown(e.clientX, e.clientY);
    const onTouchStart = (e) => {
      if (e.touches && e.touches[0]) {
        handlePointerDown(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    mount.addEventListener('mousedown', onMouseDown);
    mount.addEventListener('touchstart', onTouchStart, { passive: true });

    // ────────────────────────────────────────────────────────────────────────
    // Loop de animación principal
    // ────────────────────────────────────────────────────────────────────────
    let totalTime = 0;

    const animate = () => {
      frameRef.current = requestAnimationFrame(animate);

      const now = performance.now();
      const delta = Math.min((now - lastTimeRef.current) / 1000, 0.1);
      lastTimeRef.current = now;
      totalTime += delta;

      // 1. Animación viva de Echi (flota, respira, mueve manitas)
      if (echiRef.current) {
        echiRef.current.position.y = Math.sin(totalTime * 2.2) * 0.18;
        echiRef.current.rotation.z = Math.sin(totalTime * 1.5) * 0.04;

        // Squash & stretch al hacer tap
        tapSquashRef.current += (1.0 - tapSquashRef.current) * 0.18;
        const s = tapSquashRef.current;
        echiRef.current.scale.set(1.0 / Math.sqrt(s), s, 1.0);

        // Manitas ondeando
        if (echiVisualsRef.current.handR) {
          echiVisualsRef.current.handR.rotation.z = Math.sin(totalTime * 4.0) * 0.25;
        }
      }

      // 2. Animación de la persona a proteger (respiración suave)
      if (personRef.current) {
        personRef.current.position.y = Math.sin(totalTime * 1.6) * 0.08;
      }

      // 3. Control del Escudo
      const isShieldActive = shieldActiveRef.current;
      if (shieldMeshRef.current) {
        const targetOpacity = isShieldActive ? 0.72 : 0;
        shieldMeshRef.current.material.opacity +=
          (targetOpacity - shieldMeshRef.current.material.opacity) * 0.22;
        shieldMeshRef.current.rotation.y += 0.04;
        shieldMeshRef.current.rotation.z += 0.02;
      }

      if (outerGlowRef.current) {
        const targetGlowOpacity = isShieldActive ? 0.45 : 0;
        outerGlowRef.current.material.opacity +=
          (targetGlowOpacity - outerGlowRef.current.material.opacity) * 0.18;
        outerGlowRef.current.rotation.z -= 0.025;
      }

      // 4. Florecimiento del Escudo (Echinacea Petals)
      // Se expande y rota según la racha!
      const currentStreak = streakRef.current;
      if (petalsGroupRef.current) {
        let targetPetalScale = 0;
        if (currentStreak >= 3) {
          // Crece con la racha
          targetPetalScale = 1.0 + Math.min((currentStreak - 3) * 0.12, 0.6);
        }

        // Si el escudo está activo se abren aún más majestuosos
        if (isShieldActive && currentStreak >= 3) {
          targetPetalScale *= 1.15;
        }

        const currentScale = petalsGroupRef.current.scale.x;
        const newScale = currentScale + (targetPetalScale - currentScale) * 0.12;
        petalsGroupRef.current.scale.set(newScale, newScale, newScale);
        petalsGroupRef.current.rotation.z += 0.015 * (1 + currentStreak * 0.1);
      }

      // 5. Mover y evaluar Virus
      const weather = gameStateRef.current?.weather || 'cloudy';
      const config = WEATHER_CONFIG[weather] || WEATHER_CONFIG.cloudy;
      const removeList = [];

      virusesRef.current.forEach((v) => {
        // Avance hacia Echi con trayectoria sinusoidal orgánica
        v.mesh.position.x += v.speed;
        v.mesh.position.y = v.baseY + Math.sin(totalTime * v.sineFreq + v.seed) * v.sineAmp;
        v.mesh.rotation.z += 0.04;
        v.mesh.rotation.y += 0.03;

        // ¿Llegó a la zona de defensa de Echi (X >= 2.2)?
        if (v.mesh.position.x >= 2.2) {
          if (shieldActiveRef.current) {
            // ¡Bloqueo exitoso!
            onScore(v.id);
            createBlockExplosion(v.mesh.position, scene, streakRef.current);
          } else {
            // ¡El virus pasó! Se pierde una oportunidad
            onMiss(v.id);
            createMissFlash(v.mesh.position, scene);
          }
          scene.remove(v.mesh);
          removeList.push(v.id);
        }
      });

      virusesRef.current = virusesRef.current.filter((v) => !removeList.includes(v.id));

      // 6. Actualizar partículas de impacto / polen floral
      particlesRef.current = particlesRef.current.filter((p) => {
        p.mesh.position.x += p.vx * delta * 60;
        p.mesh.position.y += p.vy * delta * 60;
        p.mesh.position.z += p.vz * delta * 60;
        p.life -= delta;

        const progress = Math.max(0, p.life / p.maxLife);
        p.mesh.material.opacity = progress;
        p.mesh.scale.setScalar(progress);

        if (p.life <= 0) {
          scene.remove(p.mesh);
          return false;
        }
        return true;
      });

      renderer.render(scene, camera);
    };

    animate();

    // Resize
    const onResize = () => {
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      const newAspect = w / h;
      camera.left = (-frustumSize * newAspect) / 2;
      camera.right = (frustumSize * newAspect) / 2;
      camera.top = frustumSize / 2;
      camera.bottom = -frustumSize / 2;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(frameRef.current);
      clearInterval(spawnTimerRef.current);
      window.removeEventListener('resize', onResize);
      mount.removeEventListener('mousedown', onMouseDown);
      mount.removeEventListener('touchstart', onTouchStart);
      renderer.dispose();
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Generación de Virus durante la partida ───────────────────────────────
  useEffect(() => {
    clearInterval(spawnTimerRef.current);
    if (gameState?.status !== 'playing') return;

    const weather = gameState.weather || 'cloudy';
    const config = WEATHER_CONFIG[weather] || WEATHER_CONFIG.cloudy;

    spawnTimerRef.current = setInterval(() => {
      if (!sceneRef.current) return;
      if (virusesRef.current.length >= config.maxViruses) return;

      const spawnData = randomSpawn();
      const virus = buildVirusMesh(config, spawnData);
      sceneRef.current.add(virus.mesh);
      virusesRef.current.push(virus);
    }, config.spawnInterval);

    return () => clearInterval(spawnTimerRef.current);
  }, [gameState?.status, gameState?.weather]);

  // Limpiar virus al reiniciar o terminar
  useEffect(() => {
    if (gameState?.status === 'idle' || gameState?.status === 'gameover') {
      virusesRef.current.forEach((v) => sceneRef.current?.remove(v.mesh));
      virusesRef.current = [];
    }
  }, [gameState?.status]);

  // ── Explosión de Bloqueo y Polen Floral ──────────────────────────────────
  function createBlockExplosion(pos, scene, currentStreak) {
    const isBlooming = currentStreak >= 3;
    // Colores dorados, celestes y pétalos magenta si florece
    const colors = isBlooming
      ? [0xffd700, 0xff6b8b, 0xff9ff3, 0x54a0ff, 0xffffff]
      : [0x4fc3f7, 0x81d4fa, 0xffeb3b, 0xffffff];

    const particleCount = isBlooming ? 24 : 14;

    for (let i = 0; i < particleCount; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: colors[Math.floor(Math.random() * colors.length)],
        transparent: true,
        opacity: 1,
      });

      const radius = 0.08 + Math.random() * 0.12;
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, 8, 8), mat);
      mesh.position.copy(pos);
      scene.add(mesh);

      const angle = Math.random() * Math.PI * 2;
      const speed = 0.08 + Math.random() * 0.18;

      particlesRef.current.push({
        mesh,
        life: 0.75 + Math.random() * 0.35,
        maxLife: 0.9,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed + 0.03,
        vz: (Math.random() - 0.5) * 0.05,
      });
    }
  }

  // Flash cuando el virus pasa
  function createMissFlash(pos, scene) {
    for (let i = 0; i < 8; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xff4757,
        transparent: true,
        opacity: 0.9,
      });
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 6), mat);
      mesh.position.copy(pos);
      scene.add(mesh);

      particlesRef.current.push({
        mesh,
        life: 0.5,
        maxLife: 0.5,
        vx: (Math.random() - 0.5) * 0.12,
        vy: (Math.random() - 0.5) * 0.12,
        vz: 0,
      });
    }
  }

  return (
    <div
      ref={mountRef}
      className="game-canvas"
      style={{ cursor: 'pointer', touchAction: 'none' }}
    />
  );
}

// ── Constructor de Virus Simbólicos ─────────────────────────────────────────
function buildVirusMesh(config, spawn) {
  const group = new THREE.Group();
  group.position.set(spawn.x, spawn.y, spawn.z);

  // Núcleo del virus con relieve
  const coreGeo = new THREE.SphereGeometry(0.48, 20, 20);
  const coreMat = new THREE.MeshStandardMaterial({
    color: config.color,
    roughness: 0.3,
    metalness: 0.15,
  });
  const core = new THREE.Mesh(coreGeo, coreMat);
  group.add(core);

  // Espículas / Puntas características
  const spikeMat = new THREE.MeshStandardMaterial({
    color: config.spikeColor,
    roughness: 0.4,
  });
  const spikeCount = config.type === 'snow' ? 12 : 9;

  for (let i = 0; i < spikeCount; i++) {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.32, 6), spikeMat);
    const phi = Math.acos(-1 + (2 * i) / spikeCount);
    const theta = Math.sqrt(spikeCount * Math.PI) * phi;
    cone.position.setFromSphericalCoords(0.56, phi, theta);
    cone.lookAt(0, 0, 0);
    cone.rotateX(Math.PI / 2);
    group.add(cone);
  }

  // Ojos caricaturescos y pícaros
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x000000 });

  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 10), eyeMat);
  eyeL.position.set(0.18, 0.12, 0.44);
  const pupilL = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), pupilMat);
  pupilL.position.set(0.2, 0.12, 0.52);
  group.add(eyeL, pupilL);

  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 10), eyeMat);
  eyeR.position.set(0.18, -0.12, 0.44);
  const pupilR = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), pupilMat);
  pupilR.position.set(0.2, -0.12, 0.52);
  group.add(eyeR, pupilR);

  // Cejitas enfadadas
  const browGeo = new THREE.BoxGeometry(0.04, 0.16, 0.02);
  const browMat = new THREE.MeshBasicMaterial({ color: 0x222222 });
  const brow = new THREE.Mesh(browGeo, browMat);
  brow.position.set(0.22, 0, 0.5);
  brow.rotation.z = Math.PI / 2;
  group.add(brow);

  return {
    id: virusGlobalId++,
    mesh: group,
    baseY: spawn.y,
    sineFreq: spawn.sineFreq,
    sineAmp: spawn.sineAmp,
    seed: spawn.seed,
    speed: config.baseSpeed + Math.random() * config.speedVariation,
  };
}
